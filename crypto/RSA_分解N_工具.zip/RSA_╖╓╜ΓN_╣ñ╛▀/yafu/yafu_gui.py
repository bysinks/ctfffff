import subprocess
from tkinter import *
from tkinter import scrolledtext
from threading import Thread,Lock,Semaphore


class mygui():
    def __init__(self,root1):
        self.window_name =root1

     #窗口函数
    def set_window(self):
        # 窗口名基本设置，主要调整尺寸
        self.window_name.title("RSA_调用yafu分解N   By:风二西 2021.08.07")
        # 290 160为窗口大小，+10 +10 定义窗口弹出时的默认展示位置
        self.window_name.geometry('600x200+100+10')
        #输入标题
        self.input_label = Label(self.window_name,text="输入待分解的N",anchor=W)
        self.input_label.pack(fill=BOTH,)
        #输入框
        self.input_text = scrolledtext.ScrolledText(self.window_name,height=5,bg="Ivory")
        self.input_text.pack(fill=BOTH,expand=True)

        #输出标题
        self.tab3 = Label(self.window_name,text="",anchor=W)
        self.tab3.pack(fill=BOTH,pady=1)
        self.kais_button = Button(self.window_name, text="开始分解",
                                 width=15,
                                 command=lambda: self.thread123(self.yafu_def, ))
        self.kais_button.pack(fill=BOTH, in_=self.tab3,side="left",padx=2)


    def yafu_def(self):
        num1=self.input_text.get(1.0,'end').strip()
        a = subprocess.call(r'yafu-x64.exe factor({})'.format(num1),
                             shell=True,
                             )

    @staticmethod
    def thread123(func, *args):
            '''将函数打包进线程'''
            # 创建
            t = Thread(target=func, args=args)
            # 守护 !!!
            t.setDaemon(True)
            # 启动
            t.start()
            # 阻塞--卡死界面！
            # t.join()



def gui_start():
    root= Tk()              #实例化出一个父窗口
    ZMJ_PORTAL = mygui(root)
    # 设置根窗口默认属性
    #root.after(1000)
    ZMJ_PORTAL.set_window()
    root.mainloop()          #父窗口进入事件循环，可以理解为保持窗口运行，否则界面不展示
gui_start()